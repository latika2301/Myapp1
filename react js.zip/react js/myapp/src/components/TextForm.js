import React, { useState } from 'react'

export default function TextForm(props) {

    const handleupclick = () => {
        console.log('uppercase was clicked');
        let newText = text.toUpperCase();
        setText(newText)
    }
    const handleloclick = () => {
        //console.log('uppercase was clicked');
        let newText = text.toLowerCase();
        setText(newText)
        props.showAlert("successfully change into lowercase","success");
    }
    /*const handlecopy =()=>{
        //console.log('uppercase was clicked');
        var text = document.getElementById('Textbox')
        
        navigator.clipboard.writeText(text);
    }*/
    const handleremovespace = () => {
        let newText = text.split(/[ ]+/)
        setText(newText.join(" "));
    }

    const handleonchange = (event) => {
        console.log('text change');
        setText(event.target.value);
    }
    const [text, setText] = useState('enter text here')


    return (
        <>
            <div className="container" style={{ color: props.mode === 'dark' ? 'white' : 'black' }}> <h1 >{props.heading}
            </h1>
                <div className="mb-3">
                    <label htmlFor="Textbox" className="form-label" >text box</label>
                    <textarea className="form-control" value={text} id="Textbox" style={{ background: props.mode === 'dark' ? 'grey' : 'white', color: props.mode === 'dark' ? 'white' : 'black' }} onChange={handleonchange} rows="8"></textarea>
                </div>
                <button className="btn btn-primary mx-2" onClick={handleupclick}>convert to uppercase</button>
                <button className="btn btn-primary mx-2" onClick={handleloclick}>convert to lowercase</button>

                <button className="btn btn-primary mx-2" onClick={handleremovespace}>remove extra spaces</button>


            </div>
            <div className="container my-3" style={{ color: props.mode === 'dark' ? 'white' : 'black' }}>
                <h1>your text summary</h1>
                <p>{text.split(" ").length} words and {text.length} characters</p>
                <p>{0.008 * (text.split(" ").length)} time to read</p>
                <h1>preview</h1>
                <p>{text}</p>
            </div>
        </>


    )
}

